ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c      AIR 2 DXF
c      Converts any .dat airfoil to .dxf
c      by Pere Casellas
c      Laboratori d'envol http://www.laboratoridenvol.com
c      FORTRAN g77 (GNU/Linux)
c      Version 20130814
ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc

air2dxf 

This small program converts any airfoil file in standard .dat format, to .dxf file ( .dat to .dxf ) for use and analyze in CAD programs.

Use: simply, put your airfoil.dat file (using exactly this name) in the same folder as the air2dxf.exe (and cygwing1.dll) or air2dxf.out, and then execute the program. Program asks for a scale factor in thickness (normally 1.0), and then outputs airfoil.dxf and new.dat files.

The estructure of the standard .dat file:

First row: name ot the airfoil
Second row, and the following: x-coordinate  y-coordinate

bhl2-01
1.000000    0.000000
0.992800    0.001570
0.979890    0.004390
0.963520    0.007910
0.944550    0.011920
0.923500    0.016300
0.900750    0.020970
......

You may edit any .dat file simpli changing the extension .dat by .txt and then open using any text editor (kedit, notepad, word,...). However, I recommend for all these tasks with text files, the editor gvim.

Typically, the points of the .dat file are ordered so that it begins by the trailing edge (1.0 , 0.0), continuing by the upper surface of the profile, to the leading edge (0.0 , 0.0), continuing to the bottom surface, and up again to reach the trailing edge (1.0 , 0.0).  If the profile has the chord measuring the unit, its coordinates x vary in the interval [0, 1]. This is normal. But sometimes the profile can have a chord lenght of 100.0 or any other measure. This is not a problem, because the program detects this situation and turns the profile unitary by dividing all coordinates ( x, y ) by the first x-coordinate of the .dat file.

The program have as option, set the thickness os the new airfoil, by scaling with one parameter around 1.0. I.e. if the parameter is set to 0.7 the tickness will be reduced by 30%. This feature works with any type of Airfoil, even single skin sawtooth type.

List of files included with the program

Source code: air2dxf.f (GNU Fortran)

Input file:  airfoil.dat  will be any standard .dat file, but renamed to "airfoil.dat"

Executable program:

In GNU/Linux:   In a console type ./air2dxf.out

In Windows: SImply double click in air2dxf.exe but will be also necessary the file cygwin1.dll in the same folder.

Program ask for a scale parameter, and then press enter.

Output files:

new.dat the normalized (chord set to 1.0) and scaled in thickness new airfoil
airfoil.dxf  the .dxf version of the new airfoil. New chord is 100 units.

All files, input, executables, and output will be in the same folder, named for example air2dxf.

IMPORTANT NOTE: in some recent Windows versions program does not work! Then if you update your cygwin1.dll for some new version and works again!

